<script src="/admin-site/vendor/apexcharts/apexcharts.min.js"></script>
<script src="/admin-site/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="/admin-site/vendor/chart.js/chart.umd.js"></script>
<script src="/admin-site/vendor/echarts/echarts.min.js"></script>
<script src="/admin-site/vendor/quill/quill.js"></script>
<script src="/admin-site/vendor/simple-datatables/simple-datatables.js"></script>
<script src="/admin-site/vendor/tinymce/tinymce.min.js"></script>
<script src="/admin-site/vendor/php-email-form/validate.js"></script>

<!-- Template Main JS File -->
<script src="/admin-site/js/main.js"></script>