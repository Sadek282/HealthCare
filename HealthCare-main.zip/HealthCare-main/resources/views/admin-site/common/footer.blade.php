<footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>Rifat Mia</span></strong>. All Rights Reserved
    </div>
    </div>
  </footer>